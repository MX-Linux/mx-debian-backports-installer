<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ru">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="14"/>
        <location filename="../mainwindow.cpp" line="342"/>
        <location filename="../mainwindow.cpp" line="349"/>
        <location filename="../mainwindow.cpp" line="356"/>
        <source>MX Debian Backports Installer</source>
        <translation>MX Установщик Debian Backports</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="78"/>
        <source>Package Name</source>
        <translation>Имя пакета</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="83"/>
        <source>Version</source>
        <translation>Версия</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="88"/>
        <source>Description</source>
        <translation>Описание</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="96"/>
        <source>Greyed out items have already been installed.</source>
        <translation>Выделенные серым цветом пункты уже установлены.</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="109"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;= Upgradable package. Newer version available in backports repository.</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;= Пакет может быть обновлен. Более поздняя версия доступна в репозитории Backports.</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="148"/>
        <source>Display help </source>
        <translation>Показать справку</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="151"/>
        <source>Help</source>
        <translation>Справка</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="158"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="203"/>
        <source>About this application</source>
        <translation>Об этом приложении</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="206"/>
        <source>About...</source>
        <translation>O...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="213"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="229"/>
        <source>Quit application</source>
        <translation>Выйти из приложения</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="232"/>
        <source>Close</source>
        <translation>Закрыть</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="239"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="277"/>
        <source>Install</source>
        <translation>Установить</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="306"/>
        <source>search</source>
        <translation>поиск</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="117"/>
        <source>Warning</source>
        <translation>Предупреждение</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="118"/>
        <source>You are about to use Debian Backports, which contains packages taken from the next Debian release (called &apos;testing&apos;), adjusted and recompiled for usage on Debian stable. They cannot be tested as extensively as in the stable releases of Debian and MX Linux, and are provided on an as-is basis, with risk of incompatibilities with other components in Debian stable. Use with care!</source>
        <translation>Вы собираетесь использовать Debian Backports, который содержит пакеты, взятые из следующего выпуска Debian (именуемого &quot;testing&quot;), скорректированные и перекомпилированные для использования на Debian stable. Они не могли быть проверены так хорошо, как в стабильных версиях Debian и MX Linux, и предоставляются на основании &quot;как есть&quot;, с риском несовместимости с другими компонентами в Debian stable. Используйте с осторожностью!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="126"/>
        <source>Do not show this message again</source>
        <translation>Больше не показывать это окно</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="199"/>
        <location filename="../mainwindow.cpp" line="214"/>
        <source>Version </source>
        <translation>Версия</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="199"/>
        <source> in stable repo</source>
        <translation>в стабильном репозитории</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="203"/>
        <source>Not available in stable repo</source>
        <translation>Недоступно в стабильном репозитории</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="209"/>
        <source>Latest version </source>
        <translation>Последняя версия</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="209"/>
        <source> already installed</source>
        <translation>уже установлено</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="214"/>
        <source> installed</source>
        <translation>установлено</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="270"/>
        <source>Please wait till the database is loaded.</source>
        <translation>Пожалуйста, ждите загрузки базы данных.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="341"/>
        <source>About MX Debian Backports Installer</source>
        <translation>О MX Установщике Debian Backports</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="342"/>
        <source>Version: </source>
        <translation>Версия:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="343"/>
        <source>App for installing directly from Debian Backports Repo</source>
        <translation>Приложение для установки непосредственно из репозитория Debian Backports</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="345"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Авторское право (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="346"/>
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="347"/>
        <location filename="../mainwindow.cpp" line="349"/>
        <source>License</source>
        <translation>Лицензия</translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <location filename="../main.cpp" line="53"/>
        <source>Unable to get exclusive lock</source>
        <translation>Не удалось получить свою блокировку</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="54"/>
        <source>Another package management application (like Synaptic or apt-get), is already running. Please close that application first</source>
        <translation>Другое приложение управления пакетами (например, Synaptic или apt-get), уже работает. Пожалуйста, закройте сначала это приложение</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="67"/>
        <source>You must run this program as root.</source>
        <translation>Вы должны запустить программу от имени суперпользователя.</translation>
    </message>
</context>
</TS>
