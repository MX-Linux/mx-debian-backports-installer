<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ja">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="14"/>
        <location filename="../mainwindow.cpp" line="342"/>
        <location filename="../mainwindow.cpp" line="349"/>
        <location filename="../mainwindow.cpp" line="356"/>
        <source>MX Debian Backports Installer</source>
        <translation>MX Debian Backports Installer</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="78"/>
        <source>Package Name</source>
        <translation>パッケージ名</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="83"/>
        <source>Version</source>
        <translation>バージョン</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="88"/>
        <source>Description</source>
        <translation>説明</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="96"/>
        <source>Greyed out items have already been installed.</source>
        <translation>グレー表示の項目はすでにインストールされています。</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="109"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;= Upgradable package. Newer version available in backports repository.</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;= Upgradable package. backports リポジトリで利用可能な新しいバージョンがあります</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="148"/>
        <source>Display help </source>
        <translation>ヘルプの表示</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="151"/>
        <source>Help</source>
        <translation>ヘルプ</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="158"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="203"/>
        <source>About this application</source>
        <translation>このアプリケーションについて</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="206"/>
        <source>About...</source>
        <translation>About...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="213"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="229"/>
        <source>Quit application</source>
        <translation>アプリケーションの終了</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="232"/>
        <source>Close</source>
        <translation>閉じる</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="239"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="277"/>
        <source>Install</source>
        <translation>インストール</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="306"/>
        <source>search</source>
        <translation>検索</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="117"/>
        <source>Warning</source>
        <translation>注意</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="118"/>
        <source>You are about to use Debian Backports, which contains packages taken from the next Debian release (called &apos;testing&apos;), adjusted and recompiled for usage on Debian stable. They cannot be tested as extensively as in the stable releases of Debian and MX Linux, and are provided on an as-is basis, with risk of incompatibilities with other components in Debian stable. Use with care!</source>
        <translation>Debian バックポート は次期バージョンの Debian（テスト版 testing といわれます）から取られ、Debian 安定版で使用できるように調整したパッケージが含まれています。Debian と MX Linux の安定版リリースにおけるほど多くテストすることができず、Debian 安定版にある他のアプリ互換性がない事へのリスクがある状態で、そのまま提供されています。注意して使用してください！</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="126"/>
        <source>Do not show this message again</source>
        <translation>このメッセージを再度表示しない</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="199"/>
        <location filename="../mainwindow.cpp" line="214"/>
        <source>Version </source>
        <translation>Version </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="199"/>
        <source> in stable repo</source>
        <translation>標準リポジトリ</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="203"/>
        <source>Not available in stable repo</source>
        <translation>標準リポジトリが使用できません</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="209"/>
        <source>Latest version </source>
        <translation>最新バージョン</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="209"/>
        <source> already installed</source>
        <translation>すでにインストールしています</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="214"/>
        <source> installed</source>
        <translation>インストール済</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="270"/>
        <source>Please wait till the database is loaded.</source>
        <translation>データベースを読み込むため、しばらくお待ちください。</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="341"/>
        <source>About MX Debian Backports Installer</source>
        <translation>MX Debian Backports インストーラーについて</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="342"/>
        <source>Version: </source>
        <translation>Version: </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="343"/>
        <source>App for installing directly from Debian Backports Repo</source>
        <translation>Debian Backports リポジトリを直接インストールするアプリ</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="345"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="346"/>
        <source>Cancel</source>
        <translation>キャンセル</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="347"/>
        <location filename="../mainwindow.cpp" line="349"/>
        <source>License</source>
        <translation>ライセンス</translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <location filename="../main.cpp" line="53"/>
        <source>Unable to get exclusive lock</source>
        <translation>排他ロックを取得できません</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="54"/>
        <source>Another package management application (like Synaptic or apt-get), is already running. Please close that application first</source>
        <translation>別のパッケージ管理アプリケーション (Synaptic や apt-get) がすでに実行されています。まずそのアプリケーションを閉じてください</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="67"/>
        <source>You must run this program as root.</source>
        <translation>このプログラムは root で実行する必要があります。</translation>
    </message>
</context>
</TS>
