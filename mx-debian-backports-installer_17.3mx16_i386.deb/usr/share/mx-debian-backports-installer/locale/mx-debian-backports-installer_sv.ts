<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="sv">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="14"/>
        <location filename="../mainwindow.cpp" line="399"/>
        <location filename="../mainwindow.cpp" line="406"/>
        <location filename="../mainwindow.cpp" line="413"/>
        <source>MX Debian Backports Installer</source>
        <translation>MX Debian Backports Installerare</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="78"/>
        <source>Package Name</source>
        <translation>Paketnamn</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="83"/>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="88"/>
        <source>Description</source>
        <translation>Beskrivning</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="93"/>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="98"/>
        <source>Displayed</source>
        <translation>Visad</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="106"/>
        <source>Greyed out items have already been installed.</source>
        <translation>Gråmarkerade objekt har redan installerats.</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="119"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;= Upgradable package. Newer version available in backports repository.</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;= Uppgraderbart paket. Nyare version finns i backports förrådet.</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="158"/>
        <source>Display help </source>
        <translation>Visa hjälp</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="161"/>
        <source>Help</source>
        <translation>Hjälp</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="168"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="213"/>
        <source>About this application</source>
        <translation>Om detta program</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="216"/>
        <source>About...</source>
        <translation>Om...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="223"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="239"/>
        <source>Quit application</source>
        <translation>Avsluta programmet</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="242"/>
        <source>Close</source>
        <translation>Stäng</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="249"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="287"/>
        <source>Install</source>
        <translation>Installera</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="316"/>
        <source>search</source>
        <translation>sök</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="330"/>
        <location filename="../mainwindow.cpp" line="346"/>
        <source>All packages</source>
        <translation>Alla paket</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="335"/>
        <location filename="../mainwindow.cpp" line="358"/>
        <source>Installed</source>
        <translation>Installerad</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="340"/>
        <location filename="../mainwindow.cpp" line="356"/>
        <source>Upgradable</source>
        <translation>Uppgraderingsbar</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="345"/>
        <location filename="../mainwindow.cpp" line="360"/>
        <source>Not installed</source>
        <translation>Inte installerad</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="123"/>
        <source>Warning</source>
        <translation>Varning</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="124"/>
        <source>You are about to use Debian Backports, which contains packages taken from the next Debian release (called &apos;testing&apos;), adjusted and recompiled for usage on Debian stable. They cannot be tested as extensively as in the stable releases of Debian and MX Linux, and are provided on an as-is basis, with risk of incompatibilities with other components in Debian stable. Use with care!</source>
        <translation>Du är på väg att använda Debian Backports, som innehåller paket från nästa Debianutgåva (kallad &apos;testing&apos;), justerade och omkompilerade för användning i Debian stable. De kan inte testas lika noga som i de stabila utgåvorna av Debian och MX Linux, och kommer som de är, med risk för inkompatibilitet med andra komponenter i Debian stable. Använd försiktigt!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="132"/>
        <source>Do not show this message again</source>
        <translation>Visa inte det här meddelandet igen</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="207"/>
        <location filename="../mainwindow.cpp" line="225"/>
        <source>Version </source>
        <translation>Version</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="207"/>
        <source> in stable repo</source>
        <translation>i stabila förrådet (stable)</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="212"/>
        <source>Not available in stable repo</source>
        <translation>Ej tillgängligt i stabila förrådet, stable</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="219"/>
        <source>Latest version </source>
        <translation>Senaste version</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="219"/>
        <source> already installed</source>
        <translation>redan installerad</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="225"/>
        <source> installed</source>
        <translation>installerad</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="286"/>
        <source>Please wait till the database is loaded.</source>
        <translation>Var vänlig vänta tills databasen har laddats.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="398"/>
        <source>About MX Debian Backports Installer</source>
        <translation>Om MX Debian Backports Installerare</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="399"/>
        <source>Version: </source>
        <translation>Version</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="400"/>
        <source>App for installing directly from Debian Backports Repo</source>
        <translation>Program för att installera direkt från Debian Backports Repo</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="402"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="403"/>
        <source>Cancel</source>
        <translation>Avbryt</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="404"/>
        <location filename="../mainwindow.cpp" line="406"/>
        <source>License</source>
        <translation>Licens</translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <location filename="../main.cpp" line="53"/>
        <source>Unable to get exclusive lock</source>
        <translation>Kan inte utföra exklusiv låsning</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="54"/>
        <source>Another package management application (like Synaptic or apt-get), is already running. Please close that application first</source>
        <translation>En annan pakethanterare (som Synaptic eller apt-get), körs redan. Var vänlig stäng det programmet först</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="67"/>
        <source>You must run this program as root.</source>
        <translation>Du måste köra detta program som root</translation>
    </message>
</context>
</TS>
