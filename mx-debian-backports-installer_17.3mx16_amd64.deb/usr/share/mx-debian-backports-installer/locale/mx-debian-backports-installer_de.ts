<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="de">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="14"/>
        <location filename="../mainwindow.cpp" line="399"/>
        <location filename="../mainwindow.cpp" line="406"/>
        <location filename="../mainwindow.cpp" line="413"/>
        <source>MX Debian Backports Installer</source>
        <translation>MX Debian Backports Installer (für Rückportierungen)</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="78"/>
        <source>Package Name</source>
        <translation>Name des packages</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="83"/>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="88"/>
        <source>Description</source>
        <translation>Beschreibung</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="93"/>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="98"/>
        <source>Displayed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="106"/>
        <source>Greyed out items have already been installed.</source>
        <translation>Die ausgegrauten Einträge sind Pakete, die bereits installiert wurden.</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="119"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;= Upgradable package. Newer version available in backports repository.</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;= Upgrade-fähiges package. Neuere Version im backports repository verfügbar.</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="158"/>
        <source>Display help </source>
        <translation>Hilfe anzeigen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="161"/>
        <source>Help</source>
        <translation>Hilfe</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="168"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="213"/>
        <source>About this application</source>
        <translation>Infos zu diesem Programm</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="216"/>
        <source>About...</source>
        <translation>Über...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="223"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="239"/>
        <source>Quit application</source>
        <translation>Anwendung beenden</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="242"/>
        <source>Close</source>
        <translation>Schließen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="249"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="287"/>
        <source>Install</source>
        <translation>Installieren</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="316"/>
        <source>search</source>
        <translation>Suche </translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="330"/>
        <location filename="../mainwindow.cpp" line="346"/>
        <source>All packages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="335"/>
        <location filename="../mainwindow.cpp" line="358"/>
        <source>Installed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="340"/>
        <location filename="../mainwindow.cpp" line="356"/>
        <source>Upgradable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="345"/>
        <location filename="../mainwindow.cpp" line="360"/>
        <source>Not installed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="123"/>
        <source>Warning</source>
        <translation>Warnung</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="124"/>
        <source>You are about to use Debian Backports, which contains packages taken from the next Debian release (called &apos;testing&apos;), adjusted and recompiled for usage on Debian stable. They cannot be tested as extensively as in the stable releases of Debian and MX Linux, and are provided on an as-is basis, with risk of incompatibilities with other components in Debian stable. Use with care!</source>
        <translation>Vorsicht! Im Weiteren wird &quot;Debian Backports&quot; benutzt. Deren packages kommen aus &quot;testing&quot;, also den jeweils zukünftigen Paketfreigaben. Solche &quot;testing-Pakete&quot; wurden (in geringem Umfang) angepaßt und kompiliert und sind dadurch nun lauffähig in einer &quot;Debian stable&quot; Installation. Trotzdem können solche Rückportierungen nicht so aufwändig qualitätsgeprüft werden wie die original &quot;stable&quot; Pakete selbst. Deshalb kann und wird es zu Inkompatibilitäten mit anderen &quot;Debian stable&quot; Komponenten kommen. Also Backports mit Umsicht verwenden! Backports ergeben Sinn wegen ihrer Sicherheits-patches oder neuer Programmfeatures. </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="132"/>
        <source>Do not show this message again</source>
        <translation>Diesen Hinweis nicht wiederholen (nerv&apos; mich nicht mit dem Fenster!)</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="207"/>
        <location filename="../mainwindow.cpp" line="225"/>
        <source>Version </source>
        <translation>Version</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="207"/>
        <source> in stable repo</source>
        <translation>aus dem Paket-Repo für &quot;stabil&quot;</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="212"/>
        <source>Not available in stable repo</source>
        <translation>in &quot;stabil&quot; Repo nicht vorhanden</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="219"/>
        <source>Latest version </source>
        <translation>Neueste Version</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="219"/>
        <source> already installed</source>
        <translation>bereits schon installiert</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="225"/>
        <source> installed</source>
        <translation>installiert</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="286"/>
        <source>Please wait till the database is loaded.</source>
        <translation>Datenbank wird geladen... bitte warten</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="398"/>
        <source>About MX Debian Backports Installer</source>
        <translation>Impressum des MX Debian Backports Installer</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="399"/>
        <source>Version: </source>
        <translation>Version:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="400"/>
        <source>App for installing directly from Debian Backports Repo</source>
        <translation>App, um packages direkt aus dem Debian Backports Repo zu installieren </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="402"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="403"/>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="404"/>
        <location filename="../mainwindow.cpp" line="406"/>
        <source>License</source>
        <translation>Lizenz</translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <location filename="../main.cpp" line="53"/>
        <source>Unable to get exclusive lock</source>
        <translation>exklusiver Zugriff auf Semaphor gescheitert </translation>
    </message>
    <message>
        <location filename="../main.cpp" line="54"/>
        <source>Another package management application (like Synaptic or apt-get), is already running. Please close that application first</source>
        <translation>Ein weiterer Paketmanager (vielleicht synaptic oder apt-get) läuft zur Zeit. Bitte jenen erst beenden.</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="67"/>
        <source>You must run this program as root.</source>
        <translation>Dieses Programm muss vom Benutzer &quot;root&quot; ausgeführt werden.</translation>
    </message>
</context>
</TS>
